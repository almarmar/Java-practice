package example;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Pet {
    private StringProperty typePet;

    public StringProperty typePetStringProperty(){
        if(typePet==null){
            typePet=new SimpleStringProperty();
        }
        return typePet;
    }
    public final void setTypePet(String value){
        typePetStringProperty().set(value);
    }
    public final String getTypePet(){
        return typePetStringProperty().get();
    }
    private StringProperty namePet;

    public StringProperty namePetStringProperty(){
        if(namePet==null){
            namePet=new SimpleStringProperty();
        }
        return namePet;
    }
    public final void setNamePet(String value){
        namePetStringProperty().set(value);
    }
    public final String getNamePet(){
        return namePetStringProperty().get();
    }
    private StringProperty nameOwner;

    public StringProperty nameOwnerStringProperty(){
        if(nameOwner==null){
            nameOwner=new SimpleStringProperty();
        }
        return nameOwner;
    }
    public final void setNameOwner(String value){
        nameOwnerStringProperty().set(value);
    }
    public final String getNameOwner(){
        return nameOwnerStringProperty().get();
    }

    private IntegerProperty monthPat;

    public IntegerProperty monthPatProperty(){
        if(monthPat==null){
            monthPat= new SimpleIntegerProperty();
        }
        return monthPat;
    }
    public final void setMonthPat(Integer value){
        monthPatProperty().set(value);
    }
    public final Integer getMonthPat(){
        return monthPatProperty().get();
    }

    private IntegerProperty yearsPat;

    public IntegerProperty yearsPatProperty(){
        if(yearsPat==null){
            yearsPat= new SimpleIntegerProperty();
        }
        return yearsPat;
    }
    public final void setYearsPat(Integer value){
        yearsPatProperty().set(value);
    }
    public final Integer getYearsPat(){
        return yearsPatProperty().get();
    }

    public Pet(String typePet, String namePet, String nameOwner, int monthPat,int yearsPat){
        setTypePet(typePet);
        setNamePet(namePet);
        setNameOwner(nameOwner);
        setMonthPat(monthPat);
        setYearsPat(yearsPat);
    }
}
